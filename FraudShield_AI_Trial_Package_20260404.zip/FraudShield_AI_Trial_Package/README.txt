============================================================
  FraudShield AI - 30-Day Free Trial Package
============================================================

Welcome to FraudShield AI!

This package contains everything you need to get started:

📁 CONTENTS:

1-PLUGIN/
  └── tanveer-fraudshield-for-woocommerce.zip
       The WordPress/WooCommerce plugin

2-GUIDES/
  ├── INSTALLATION_GUIDE.pdf
  │    Complete installation instructions
  ├── QUICK_START_GUIDE.pdf
  │    Get started in 5 minutes
  └── TROUBLESHOOTING.pdf
       Common issues and solutions

3-API-KEY/
  └── YOUR_TRIAL_API_KEY.txt
       Your unique trial API key (30 days)

4-SUPPORT/
  └── SUPPORT_CONTACT.txt
       How to get help

============================================================

🚀 QUICK START:

1. Read INSTALLATION_GUIDE.pdf (5 minutes)
2. Install the plugin from 1-PLUGIN/
3. Enter your trial API key from 3-API-KEY/
4. Read QUICK_START_GUIDE.pdf to learn features

============================================================

📧 SUPPORT:

Email: support@fraudshield.ai
Docs: https://docs.fraudshield.ai
Response: Within 24 hours

============================================================

Thank you for trying FraudShield AI!

